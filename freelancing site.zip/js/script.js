// script.js

// Sample data for jobs
const jobs = Array.from({ length: 9 }, (_, index) => ({
    title: `Job Title ${index + 1}`,
    description: `Description for Job ${index + 1}. This is an example of what the job entails.`,
    budget: Math.floor(Math.random() * 1000) + 100,
  }));
  
  // Sample data for freelancers
  const freelancers = [
    { name: "John Doe", skills: "React, Node.js", rating: 4.8 },
    { name: "Jane Smith", skills: "UI/UX Design, Figma", rating: 4.9 },
    { name: "Emily Johnson", skills: "SEO, Google Ads", rating: 4.7 },
    { name: "Michael Brown", skills: "Python, Data Analysis", rating: 4.6 },
    { name: "Sarah Williams", skills: "Illustrator, Photoshop", rating: 4.5 },
    { name: "James Wilson", skills: "Angular, JavaScript", rating: 4.8 },
  ];
  
  // Sample data for skills
  const skills = [
    "React.js",
    "Node.js",
    "Angular",
    "UI/UX Design",
    "SEO",
    "Python",
    "Data Analysis",
    "Google Ads",
    "Illustrator",
    "Photoshop",
    "Content Writing",
    "Digital Marketing",
    "Mobile App Development",
    "Backend Development",
    "Game Design",
  ];
  
  // Load jobs dynamically
  function loadJobs() {
    const jobList = document.getElementById('job-list');
    jobs.forEach(job => {
      const col = document.createElement('div');
      col.className = 'col-md-6 col-lg-4';
      col.innerHTML = `
        <div class="card h-100" data-aos="fade-up">
          <div class="card-body">
            <h5 class="card-title">${job.title}</h5>
            <p class="card-text">${job.description}</p>
            <p class="card-text"><strong>Budget:</strong> $${job.budget}</p>
          </div>
        </div>
      `;
      jobList.appendChild(col);
    });
  }
  
  // Load freelancers dynamically
  function loadFreelancers() {
    const freelancerList = document.getElementById('freelancer-list');
    freelancers.forEach(freelancer => {
      const col = document.createElement('div');
      col.className = 'col-md-6 col-lg-4';
      col.innerHTML = `
        <div class="card h-100" data-aos="fade-up">
          <div class="card-body">
            <h5 class="card-title">${freelancer.name}</h5>
            <p class="card-text"><strong>Skills:</strong> ${freelancer.skills}</p>
            <p class="card-text"><strong>Rating:</strong> ⭐ ${freelancer.rating}</p>
          </div>
        </div>
      `;
      freelancerList.appendChild(col);
    });
  }
  
  // Load skills dynamically
  function loadSkills() {
    const skillList = document.getElementById('skill-list');
    skills.forEach(skill => {
      const col = document.createElement('div');
      col.className = 'col-md-3 col-sm-6';
      col.innerHTML = `
        <div class="p-3 border rounded text-center bg-light skillBtn" data-aos="zoom-in">
          <span>${skill}</span>
        </div>
      `;
      skillList.appendChild(col);
    });
  }
  
  // Initialize content on page load
  document.addEventListener('DOMContentLoaded', () => {
    loadJobs();
    loadFreelancers();
    loadSkills();
  });
  